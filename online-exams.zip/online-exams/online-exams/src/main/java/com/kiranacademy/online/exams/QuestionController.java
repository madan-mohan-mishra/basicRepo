package com.kiranacademy.online.exams;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.kiranacademy.online.exams.entity.Questions;
import com.kiranacademy.onlineexam3.Answer;

@Controller
public class QuestionController 
{

	@RequestMapping("saveResponse")
	public void saveResponse(Answer answer,HttpServletRequest request)
	{
		System.out.println(answer);
		HttpSession httpsession=request.getSession();
		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");
		
		Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
		
		String originalAnswer=question.getAnswer();
		
		System.out.println(originalAnswer);
		
		answer.setOriginalAnswer(originalAnswer);
	
		
		HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		
		hashmap.put(answer.qno, answer);
		
		System.out.println(httpsession.getAttribute("submittedDetails"));
			
	}
	
	
	@RequestMapping("endExam")
	public ModelAndView endExam(HttpServletRequest request)
	{
		
		HttpSession httpsession=request.getSession();
		HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("score");
				
		if(hashmap!=null)
		{
				Collection<Answer> collection=hashmap.values();
				
				for (Answer answer : collection) 
				{
					if(answer.originalAnswer.equals(answer.submittedAnswer))
					{
						httpsession.setAttribute("score", (int)httpsession.getAttribute("score")+1);
					}
				}
							
				httpsession.setAttribute("allanswers", collection);
				
				// remove Answer objects 
				
				httpsession.removeAttribute("submittedDetails");
		}
		
		return mv;
		
		
	}
	


	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		
		modelAndView.setViewName("questions");

		
		HttpSession httpsession=request.getSession();//httpsession==> [ qno=1 , score=0 setAttribute() ] HttpSession object
		
		
		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");
		
		
		if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2)
		{
		
				httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);
				
				Questions question =listofquestions.get((int)httpsession.getAttribute("qno"));

				

				// code to retrieve previous answer

				int qno=question.getQno(); // retrieve question number
						
				HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
				
				
				Answer answer=hashmap.get(qno);
				
				String previousAnswer="";
				
				if(answer!=null)
				{
					previousAnswer=answer.submittedAnswer;
				}
				

				
				modelAndView.addObject("question",question);
				modelAndView.addObject("previousAnswer",previousAnswer);
				
				
		}
		
		else
		{
			

			modelAndView.addObject("question",listofquestions.get(listofquestions.size()-1));
			
			
			modelAndView.addObject("message","question over");
		
		}
		
		return modelAndView;
	}
	


	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		
		HttpSession httpsession=request.getSession();//httpsession==> [ qno=1 , score=0 setAttribute() ] HttpSession object
		
		
		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");
		
		modelAndView.setViewName("questions");
		
		
		if((int)httpsession.getAttribute("qno")>0)
		{
		
				httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")-1);
				
				Questions question =listofquestions.get((int)httpsession.getAttribute("qno"));
						
				
				// code to retrieve previous answer

				int qno=question.getQno(); // retrieve question number
						
				HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
				
				
				Answer answer=hashmap.get(qno);
				
				String previousAnswer="";
				
				if(answer!=null)
				{
					previousAnswer=answer.submittedAnswer;
				}
				
				
				modelAndView.addObject("question",question);
				
				modelAndView.addObject("previousAnswer",previousAnswer);
				
				
		}
		
		else
		{
			

			modelAndView.addObject("question",listofquestions.get(0));
			
			
			modelAndView.addObject("message","question over");
		
		}
		
		return modelAndView;
	}
	




}




