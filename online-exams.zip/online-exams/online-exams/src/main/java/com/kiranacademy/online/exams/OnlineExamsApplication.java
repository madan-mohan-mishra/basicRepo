package com.kiranacademy.online.exams;

import java.util.ArrayList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineExamsApplication {

	public static int a;
	public static ArrayList al=new ArrayList();
	
	
	public static void main(String[] args) 
	{
		System.out.println(a);
		
		System.out.println(al.size());
		
		SpringApplication.run(OnlineExamsApplication.class, args);
		
	}

}
